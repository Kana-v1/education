module.exports = {
  login: require('./login'),
  logout: require('./logout'),
  main: require('./main'),
  make: require('./make'),
  pizza: require('./pizza'),
  register: require('./register'),
  toppings: require('./toppings'),
  user: require('./user')
}
